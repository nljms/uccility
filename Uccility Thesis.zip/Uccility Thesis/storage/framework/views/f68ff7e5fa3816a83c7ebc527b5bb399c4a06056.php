<?php $__env->startSection('title', 'Administration'); ?>

<?php $__env->startSection('content'); ?>


<div></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>