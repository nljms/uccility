<?php $__env->startSection('content'); ?>

<div class="col-md-12 panel">
	<div class="panel-body">
		<div class="col-md-12">
			<form method="post" action="">
	        <?php echo e(csrf_field()); ?>

			<h1>STUDENT EVALUATION OF TEACHER PERFORMANCE</h1>
			<input type="hidden" name="student_id" value="16">
			<div class="col-md-6 form-group">
				<label for="teacher-name">Teacher's Name: </label>
				<select class="form-control" name="professor_id" id="teacher-name" style="color: black;">
					<option value="34"> Joemen Barrios</option>
					<option value="47"> Allyson Merdegia</option>
				</select>
			</div>
			<div class="col-md-6 form-group">
				<label for="subject">Subject: </label>
				<select class="form-control" name="subject" id="subject" style="color: black;">
					<option value="Thesis I"> Thesis I</option>
					<option value="Thesis II"> Thesis II</option>
				</select>
			</div>

    		<table class="table table-responsive">
                <tbody>
                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e(++$key); ?>.</td>
							<td colspan="3" style="color: #344577; font-weight: bold;"><?php echo e($topic->description); ?></td>
							<td>
								<td>
									<?php $__currentLoopData = $topic->getQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td></td>
										<td><?php echo e(++$num); ?>.</td>
										<td><?php echo e($question->question); ?></td>
										<td>
											<?php for($i = 5;$i >= 1;$i--): ?>
												<input type="radio" name="question[<?php echo e($question->id); ?>]" value="<?php echo e($i); ?>" required> <?php echo e($i); ?> &nbsp;
											<?php endfor; ?>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</td>
							</td>
						</tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    	<td colspan="4" style="text-align: center;">
                    		<button class="btn btn-primary">Submit</button>
                    	</td>
                    </tr>
                </tbody>
            </table>
        </form>
    	</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>