<?php $__env->startSection('title', 'Courses'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="col-md-12 contents">
    <div class="col-md-12 content-tiles">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/admin/registrar/records/college-of-liberal-arts-and-sciences/bscs">
        <div class="col-md-3 content-row">
            <div class="col-md-12 content-item">
                <h4><i class="fa fa-ellipsis-v pull-right"></i></h4>
                <h1 class="file-logo"><i class="icon-uccility-folder" style="color: inherit;"></i></h1>
                <h4><?php echo e($course); ?></h4>
            </div>
        </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>