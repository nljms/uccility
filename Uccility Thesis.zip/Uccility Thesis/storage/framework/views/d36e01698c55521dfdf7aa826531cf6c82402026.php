<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-5 col-md-offset-7 welcome" style="margin-top: 140px; padding-left: 80px;">
			<h3>Explore the features of Uccility! Say Goodbye to the old ways of Managing and Keeping Records!</h3>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>