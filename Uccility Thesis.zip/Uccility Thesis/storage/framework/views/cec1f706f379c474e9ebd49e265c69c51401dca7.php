<?php $__env->startSection('content'); ?>

<div class="col-md-12 panel">
	<div class="panel-body">
		<div class="col-md-12">
			<table class="table table-responsive table-bordered">
				<thead>
					<tr>
						<td>Professor: </td>
						<td colspan="2">Joemen Barrios</td>
						<td>Subject: </td>
						<td colspan="3">Thesis I</td>
					</tr>
					<tr>
						<td></td>
						<td colspan="5">Rating Count</td>
						<td></td>
					</tr>
					<tr>
						<td>Question</td>
						<td>5 - Outstanding</td>
						<td>4 - Above Average</td>
						<td>3 - Average</td>
						<td>2 - Fair</td>
						<td>1 - Poor</td>
						<td>Result</td>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $ratesPerQuestion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question_rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						<!-- $is_admin = ($user['permissions'] == 'admin') ? true : false; -->
							<td>#<?php echo e($key); ?></td>
							<?php for($i = 5;$i >= 1; $i--): ?>
							<td><?php echo e(isset($ratesPerQuestion[$key][$i]) ? $ratesPerQuestion[$key][$i] : 0); ?></td>
							<?php endfor; ?>
							<td></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td colspan="6" style="text-align: right;">Summary: </td>
						<td>Above Average</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>