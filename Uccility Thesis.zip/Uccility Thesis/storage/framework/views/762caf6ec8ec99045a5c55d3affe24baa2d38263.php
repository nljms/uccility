<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>

	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
	<link rel="icon" href="<?php echo e(asset('img/favicon.ico')); ?>">
	<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/style-icon.css')); ?>"> -->
	<link rel="stylesheet" href="<?php echo e(asset('css/style-uc.css')); ?>">
</head>
<body>
<div class="container-fluid">
	<div class="row">
		<div class="main_container">
				<?php echo $__env->make('_includes.admin-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('_includes.admin-sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="col-md-10 right_col" role="main">
					<div class="row">
						<div class="col-md-12 padd"></div>
						<div class="col-md-12 dash-info">
							<div class="col-md-12">
								<h1><?php echo $__env->yieldContent('title'); ?></h1>
							</div>
						</div>
						<?php echo $__env->yieldContent('content'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</html>