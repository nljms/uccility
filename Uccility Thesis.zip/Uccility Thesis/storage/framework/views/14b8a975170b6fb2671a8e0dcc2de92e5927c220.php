<?php $__env->startSection('title', 'Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12 contents">
    <div class="col-md-12 content-row">
        <div class="col-md-12 content-item">
            <table class="table table-responsive table-striped">
                <thead>
                    <tr>
                        <td>#</td>
                        <td>Student Number</td>
                        <td>Last Name</td>
                        <td>First Name</td>
                        <td>Middle Name</td>
                        <td>Course</td>
                        <td>Year</td>
                        <td>Section</td>
                        <td>Campus</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>20140593</td>
                        <td>Loquine</td>
                        <td>Edilbert</td>
                        <td>Pantajo</td>
                        <td>BSCS</td>
                        <td>4</td>
                        <td>C</td>
                        <td>North</td>
                        <td>
                            <button class="btn btn-primary"><i class="fa fa-eye"></i></button>
                            <button class="btn btn-success"><i class="fa fa-pencil"></i></button>
                            <button class="btn btn-warning"><i class="fa fa-trash"></i></button>
                        </td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>20140593</td>
                        <td>Loquine</td>
                        <td>Edilbert</td>
                        <td>Pantajo</td>
                        <td>BSCS</td>
                        <td>4</td>
                        <td>C</td>
                        <td>North</td>
                        <td>
                            <button class="btn btn-primary"><i class="fa fa-eye"></i></button>
                            <button class="btn btn-success"><i class="fa fa-pencil"></i></button>
                            <button class="btn btn-warning"><i class="fa fa-trash"></i></button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>