<div class="col-md-2 left_col scrollbar" id="style-1">
    <div class="left_cols">
        <div class="clearfix"></div>
        <div class="profile clearfix">
            <div class="profile_pic">
                <img src="<?php echo e(asset('storage/avatar/'.Auth::user()->photo)); ?>" class="img-circle profile_img" alt="avatar_img">
            </div>
            <div class="profile_info">
                <span><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></span>
                <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p style="color: white;"><?php echo e($role->display_name); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <?php echo $__env->make('_includes.admin-nav-permissions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>