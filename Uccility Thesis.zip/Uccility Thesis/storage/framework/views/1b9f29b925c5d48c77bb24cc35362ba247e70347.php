<?php $__env->startSection('title', 'Questionnaire'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="col-md-12 contents">
    <div class="col-md-12 content-tiles">
        <div class="col-md-12 content-wrapper">
            <div class="col-md-12 content-item bordered-o">
            	<div class="col-md-4">
            		<h2>Topics</h2>
            		<p><a href="#"><i class="fa fa-plus"></i> Add</a> | <a href="#"><i class="fa fa-pencil"></i> Edit</a></p>
            		<table class="table table-responsive table-striped">
                        <tbody>
                            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e(++$key); ?>.</td>
									<td><?php echo e($topic->description); ?></td>
								</tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            	</div>
            	<div class="col-md-8">
            		<h2>Questions</h2>
            		<p>Answerable by Rating Scale</p>
            		<p><a href="#"><i class="fa fa-plus"></i> Add</a> | <a href="#"><i class="fa fa-pencil"></i> Edit</a></p>
            		<table class="table table-responsive">
                        <tbody>
                            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e(++$key); ?>.</td>
									<td colspan="2" style="color: #344577; font-weight: bold;"><?php echo e($topic->description); ?></td>
									<td>
										<?php $__currentLoopData = $topic->getQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td></td>
												<td><?php echo e(++$num); ?>.</td>
												<td><?php echo e($question->question); ?></td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</td>
								</tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            	</div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>