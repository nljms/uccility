<?php if (app('laratrust')->hasRole('hr|registrar')) : ?>
<ul>
    <li>This is Accessible by Admin</li>
    <li>This is Accessible by Admin</li>
    <li>This is Accessible by Admin</li>

    <ul>
    <li>This is Accessible by Registrar</li>
    <li>This is Accessible by Registrar</li>
    <li>This is Accessible by Registrar</li>
</ul>
</ul>
<?php endif; // app('laratrust')->hasRole ?>
<?php if (app('laratrust')->hasRole('hr')) : ?>
<ul>
    <li>This is Accessible by HR</li>
    <li>This is Accessible by HR</li>
    <li>This is Accessible by HR</li>
</ul>
<?php endif; // app('laratrust')->hasRole ?>
<?php if (app('laratrust')->hasRole('registrar')) : ?>
    <ul>
        <li>wa</li>
    </ul>
<?php endif; // app('laratrust')->hasRole ?>