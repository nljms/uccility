<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('img/favicon.ico')); ?>">
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
    <script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
    <title>Uccility</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style-uc.css')); ?>">
</head>
<body>
    <div id="app">
        <div class="guest-body" style="margin-top: 40px;">
            <img src="<?php echo e(asset('img/homepage.png')); ?>" alt="bg-background" class="img-responsive guest-body-img">
        </div>
        <div class="parent-container">
            <?php echo $__env->make('_includes.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</body>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</html>
