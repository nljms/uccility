<?php $__env->startSection('title', 'Professors'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="col-md-12 contents">
    <div class="col-md-12 content-tiles">
        <div class="col-md-12 content-row">
            <div class="col-md-12 content-item"><br>
            <p>Showing 4 of 4...</p>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <td>#</td>
                            <td>User ID</td>
                            <td>Last name</td>
                            <td>First name</td>
                            <td>Middle name</td>
                            <td>Department</td>
                            <td>Employment Status</td>
                            <td>Campus</td>
                            <td>Actions</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($professor->id); ?></td>
                            <td><?php echo e($professor->user_id); ?></td>
                            <td><?php echo e($professor->user->last_name); ?></td>
                            <td><?php echo e($professor->user->first_name); ?></td>
                            <td><?php echo e($professor->user->middle_name); ?></td>
                            <td><?php echo e($professor->department->description); ?></td>
                            <td><?php echo e($professor->employment_status); ?></td>
                            <td><?php echo e($professor->campus); ?></td>
                            <td><button class="btn btn-info btn-o"><i class="fa fa-eye"></i></button> &nbsp;<button class="btn btn-info btn-p"><i class="fa fa-pencil"></i></button></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="col-md-12 pagination">
                    <nav>
                        <ul class="pagination">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                    <span class="sr-only">Previous</span>
                                </a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <!-- <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">4</a></li>
                            <li class="page-item"><a class="page-link" href="#">5</a></li> -->
                            <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                                <span class="sr-only">Next</span>
                            </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>