<?php $__env->startComponent('mail::message'); ?>

<h3> Your Account has been Activated! </h3>

<?php $__env->startComponent('mail::panel'); ?>
<p style="font-size: 18px; color: #ffffff">Thank you <?php echo e($data[0]->first_name); ?> <?php echo e($data[0]->last_name); ?>, you may click the link below to complete your Activation.</p>
<span style="font-size: 18px; color: rgb(252,115,73)">http://uccility.dev:8000/activate/confirmation/<?php echo e($confirmation_code); ?></span>

Contact us here: <br>
uccilityapp@gmail.com <br>
+6390123456789 <br>
123-456-789 <br>
<?php echo $__env->renderComponent(); ?>

Start using the App by Downloading:

<?php $__env->startComponent('mail::button', ['url' => 'https://github.com']); ?>
Download the App!
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?> Admin  

<?php echo $__env->renderComponent(); ?>
