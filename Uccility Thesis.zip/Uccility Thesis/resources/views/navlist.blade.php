@role('hr|registrar')
<ul>
    <li>This is Accessible by Admin</li>
    <li>This is Accessible by Admin</li>
    <li>This is Accessible by Admin</li>

    <ul>
    <li>This is Accessible by Registrar</li>
    <li>This is Accessible by Registrar</li>    
    <li>This is Accessible by Registrar</li>
</ul>
</ul>
@endrole
@role('hr')
<ul>
    <li>This is Accessible by HR</li>
    <li>This is Accessible by HR</li>
    <li>This is Accessible by HR</li>
</ul>
@endrole
@role('registrar')
    <ul>
        <li>wa</li>
    </ul>
@endrole