@extends('layouts.coor')

@section('title', 'Coordinator')

@section('content')
<div class="col-md-12 contents">
    <div class="col-md-12 content-row">
        <div class="col-md-12 content-item">
            <h1>Filtered By Section</h1>
        </div>
    </div>
    <div class="col-md-12 content-row">
        <div class="col-md-4 content-row">
               <div class="col-md-12 content-item">
               <a ><h4><i class="fa fa-ellipsis-v pull-right"></i></h4></a>
            <h1><i class="icon-uccility-file" style="font-size:250%"></i></h1><hr/>
           <a href="/coor/eval/degree/section"><h4>Section A</h4></a>
        </div>
        </div>
         <div class="col-md-4 content-row">
               <div class="col-md-12 content-item">
               <a ><h4><i class="fa fa-ellipsis-v pull-right"></i></h4></a>
            <h1><i class="icon-uccility-file" style="font-size:250%"></i></h1><hr/>
           <a href="/coor/eval/degree/section"><h4>Section B</h4></a>
        </div>
        </div>
         <div class="col-md-4 content-row">
               <div class="col-md-12 content-item">
               <a ><h4><i class="fa fa-ellipsis-v pull-right"></i></h4></a>
            <h1><i class="icon-uccility-file" style="font-size:250%"></i></h1><hr/>
           <a href="/coor/eval/degree/section"><h4>Section C</h4></a>
        </div>
        </div>
    </div>
</div>
    @stop






