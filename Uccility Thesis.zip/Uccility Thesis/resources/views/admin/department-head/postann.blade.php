   @extends('depthead.ann')

  @section('title', 'Administrator')

@section('ann-con')
        <div class="col-md-12 content-item">
            <div class="row">
              <div class="col-md-12">
              <br/>
                <textarea id="kazams"></textarea>
              </div>
            </div>
            <br/>
          <div class="row">
              <div class="col-md-10">
              </div>
              <div class="col-md-2">
                <button id="butpost">Post</button>
              </div>
            </div>
         </div>

    @stop