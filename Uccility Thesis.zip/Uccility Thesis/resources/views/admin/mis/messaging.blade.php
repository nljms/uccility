@extends('layouts.admin')

@section('title', 'Administration')
    
@section('content')
<div class="col-md-12 contents">
    <div class="col-md-12 content-tiles">
        <div class="col-md-12 content-wrapper">
            <div class="col-md-12 content-item">
                <div class="col-md-4">
                    
                    
                </div>
                <div class="col-md-4">
                    
                </div>
                <div class="col-md-4">
                    
                </div>
            </div>
        </div>
    </div>
</div>

@endsection