<?php

return [
    'role_structure' => [
        'super admin' => [
            
        ],
        'hr' => [
            
        ],
        'registrar' => [
            
        ],
        'depatment_head' => [
            
        ],
        'coordinator' => [
            
        ],
        'student_assistant' => [
            
        ],
        'professor' => [
            
        ],
        'student' => [
            
        ],
        
    ],
    'permission_structure' => [
        
    ],
    'permissions_map' => [
        
    ]
];
